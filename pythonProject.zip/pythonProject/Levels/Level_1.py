import pygame
    # Floor
    pygame.Rect(0, 579, 1280, 141),
    # Platform
    pygame.Rect(640, 385, 200, 50),
    pygame.Rect(640, 500, 50, 50)