import pygame

# Intilize the pygame
pygame.init()

# Create the screen
screen = pygame.display.set_mode((1280, 720))

# Chosing Background Image
bg_surface = pygame.image.load('Cave_1.png')

# Caption and Icon
pygame.display.set_caption("Mr.Baku")
icon = pygame.image.load('baku icon.png')
pygame.display.set_icon(icon)

# Drow and posision the Player
playerImg = pygame.image.load('RedEli.png')
playerX = 10
playerY = 500
playerX_change = 0
playerY_change = 0

# Starting Location of the player
def player(x,y):
    screen.blit(playerImg, (x, y))


# Game Loop
running = True
while running:

     # Drow Background Image
    screen.blit(bg_surface,(0, 0))

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        # Character movment
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_LEFT or event.key == ord('a'):
               playerX_change = -2.5
            if event.key == pygame.K_RIGHT or event.key == ord('d'):
               playerX_change = 2.5
            if event.key == pygame.K_UP or event.key == ord('w'):
                playerY_change = -1

        if event.type == pygame.KEYUP:
            if event.key == pygame.K_LEFT or event.key == ord('a'):
                playerX_change = 0
            if event.key == pygame.K_RIGHT or event.key == ord('d'):
                playerX_change = 0
            if event.key == pygame.K_UP or event.key == ord('w'):
                playerY_change = 0

    # Player location and movment
    playerX += playerX_change
    playerY += playerY_change
    player(playerX, playerY)

     # Player bounderies
    if playerX <= 0:
         playerX = 0
    elif playerX >= 1210:
         playerX = 1210

    pygame.display.update()